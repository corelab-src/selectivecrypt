
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.19.1'
version = '1.19.1'
full_version = '1.19.1'
git_revision = '13661ac7002a6b39072e616c19ff43daaec60f7e'
release = True

if not release:
    version = full_version
